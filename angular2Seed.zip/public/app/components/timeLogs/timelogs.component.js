System.register(['angular2/core', 'angular2/common', "../../services/timelogs.service", "angular2/router"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, common_1, timelogs_service_1, router_1;
    var TimeLogsComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (timelogs_service_1_1) {
                timelogs_service_1 = timelogs_service_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            }],
        execute: function() {
            TimeLogsComponent = (function () {
                function TimeLogsComponent(_router, _timeLogsService) {
                    this._router = _router;
                    this._timeLogsService = _timeLogsService;
                    this.timeLogs = _timeLogsService.timeLogs;
                }
                TimeLogsComponent.prototype.ngOnInit = function () {
                    this.getTimeLogs();
                };
                TimeLogsComponent.prototype.getTimeLogs = function () {
                    this._timeLogsService.getTimeLogs();
                    // .subscribe(function(heroes) {return this.timeLogs = heroes});
                    // this.timeLogs = this._timeLogsService.getTimeLogs();
                    // this.total = _.reduce(this.timeLogs, function(summ, timeLog){
                    //      return summ + timeLog.timeInMinutes;
                    // }, 0);
                    // console.log(this.total);
                };
                TimeLogsComponent.prototype.showTotalTime = function () {
                    return this.formatTime(_.reduce(this.timeLogs.data, function (summ, timeLog) {
                        return summ + timeLog.timeInMinutes;
                    }, 0));
                };
                TimeLogsComponent.prototype.formatTime = function (timeInMinutes) {
                    var timeString = "";
                    var hours = Math.floor(timeInMinutes / 60);
                    if (hours) {
                        timeString += hours + " hour";
                        timeString += hours > 1 ? "s " : " ";
                    }
                    if (timeInMinutes % 60) {
                        timeString += timeInMinutes % 60 + " minutes";
                    }
                    return timeString;
                };
                TimeLogsComponent.prototype.deleteTimeLog = function (timeLog) {
                    this._timeLogsService.deleteTimeLog(timeLog);
                };
                TimeLogsComponent.prototype.editTimeLog = function (timeLog) {
                    this._router.navigate(['AddTimeLog', { id: timeLog.id }]);
                };
                TimeLogsComponent = __decorate([
                    core_1.Component({
                        selector: 'time-logs',
                        template: "\n        <div class=\"row\">\n            <h1>Time Logs</h1>\n        </div>\n        <div class=\"row\">\n        <table class=\"table table-bordered table-striped\">\n            <tr>\n                <th>#</th> \n                <th>Description</th> \n                <th>Time in minutes</th> \n                <th>Actions</th>\n            </tr>\n            <tr *ngFor=\"#timeLog of timeLogs.data\">\n                <th scope=\"row\">{{timeLog.id}}</th> \n                <td>{{timeLog.description}}</td> \n                <td>{{formatTime(timeLog.timeInMinutes)}} </td>\n                <td><span (click)=\"editTimeLog(timeLog)\" class=\"col-sm-2\">Edit</span><span (click)=\"deleteTimeLog(timeLog)\" class=\"col-sm-2\">Delete</span></td>\n            </tr>\n        </table>\n        </div>\n        <div class=\"row\">\n            <span class=\"col-sm-2 col-md-offset-6\">Total:</span>\n            <span class=\"col-sm-2\">{{showTotalTime()}}</span>\n        </div>\n    ",
                        directives: [common_1.NgClass, common_1.NgIf, common_1.CORE_DIRECTIVES, common_1.FORM_DIRECTIVES]
                    }), 
                    __metadata('design:paramtypes', [router_1.Router, timelogs_service_1.TimeLogsService])
                ], TimeLogsComponent);
                return TimeLogsComponent;
            }());
            exports_1("TimeLogsComponent", TimeLogsComponent);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC9jb21wb25lbnRzL3RpbWVMb2dzL3RpbWVsb2dzLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztZQW9DQTtnQkFHSSwyQkFBb0IsT0FBZSxFQUFVLGdCQUFpQztvQkFBMUQsWUFBTyxHQUFQLE9BQU8sQ0FBUTtvQkFBVSxxQkFBZ0IsR0FBaEIsZ0JBQWdCLENBQWlCO29CQUMxRSxJQUFJLENBQUMsUUFBUSxHQUFHLGdCQUFnQixDQUFDLFFBQVEsQ0FBQztnQkFDOUMsQ0FBQztnQkFFRCxvQ0FBUSxHQUFSO29CQUNJLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztnQkFDdkIsQ0FBQztnQkFFRCx1Q0FBVyxHQUFYO29CQUNJLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxXQUFXLEVBQUUsQ0FBQztvQkFDaEMsZ0VBQWdFO29CQUNwRSx1REFBdUQ7b0JBQ3ZELGdFQUFnRTtvQkFDaEUsNENBQTRDO29CQUM1QyxTQUFTO29CQUNULDJCQUEyQjtnQkFDL0IsQ0FBQztnQkFFRCx5Q0FBYSxHQUFiO29CQUNJLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsVUFBUyxJQUFJLEVBQUUsT0FBTzt3QkFDakUsTUFBTSxDQUFDLElBQUksR0FBRyxPQUFPLENBQUMsYUFBYSxDQUFDO29CQUN6QyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDZixDQUFDO2dCQUVELHNDQUFVLEdBQVYsVUFBVyxhQUFhO29CQUNwQixJQUFJLFVBQVUsR0FBRyxFQUFFLENBQUM7b0JBQ3BCLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsYUFBYSxHQUFHLEVBQUUsQ0FBQyxDQUFDO29CQUMzQyxFQUFFLENBQUEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO3dCQUNQLFVBQVUsSUFBSSxLQUFLLEdBQUcsT0FBTyxDQUFDO3dCQUM5QixVQUFVLElBQUksS0FBSyxHQUFHLENBQUMsR0FBRyxJQUFJLEdBQUcsR0FBRyxDQUFDO29CQUN6QyxDQUFDO29CQUVELEVBQUUsQ0FBQSxDQUFDLGFBQWEsR0FBRyxFQUFFLENBQUMsQ0FBQSxDQUFDO3dCQUNuQixVQUFVLElBQUksYUFBYSxHQUFHLEVBQUUsR0FBRyxVQUFVLENBQUM7b0JBQ2xELENBQUM7b0JBRUQsTUFBTSxDQUFDLFVBQVUsQ0FBQztnQkFDdEIsQ0FBQztnQkFFRCx5Q0FBYSxHQUFiLFVBQWMsT0FBTztvQkFDakIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFDakQsQ0FBQztnQkFFRCx1Q0FBVyxHQUFYLFVBQVksT0FBTztvQkFDZixJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBRSxDQUFDLFlBQVksRUFBRSxFQUFDLEVBQUUsRUFBRSxPQUFPLENBQUMsRUFBRSxFQUFDLENBQUMsQ0FBRSxDQUFDO2dCQUM5RCxDQUFDO2dCQTlFTDtvQkFBQyxnQkFBUyxDQUFDO3dCQUNQLFFBQVEsRUFBRSxXQUFXO3dCQUNyQixRQUFRLEVBQUUseTlCQXdCVDt3QkFDRCxVQUFVLEVBQUUsQ0FBQyxnQkFBTyxFQUFFLGFBQUksRUFBRSx3QkFBZSxFQUFFLHdCQUFlLENBQUM7cUJBQ2hFLENBQUM7O3FDQUFBO2dCQW1ERix3QkFBQztZQUFELENBakRBLEFBaURDLElBQUE7WUFqREQsaURBaURDLENBQUEiLCJmaWxlIjoiYXBwL2NvbXBvbmVudHMvdGltZUxvZ3MvdGltZWxvZ3MuY29tcG9uZW50LmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtDb21wb25lbnQsIEV2ZW50RW1pdHRlciwgT25Jbml0fSBmcm9tICdhbmd1bGFyMi9jb3JlJztcclxuaW1wb3J0IHtDT1JFX0RJUkVDVElWRVMsIEZPUk1fRElSRUNUSVZFUywgTmdDbGFzcywgTmdJZn0gZnJvbSAnYW5ndWxhcjIvY29tbW9uJztcclxuaW1wb3J0IHtUaW1lTG9nfSBmcm9tIFwiLi4vLi4vbW9kZWwvdGltZWxvZy5tb2RlbFwiO1xyXG5pbXBvcnQge1RpbWVMb2dzU2VydmljZSwgVGltZUxvZ3NEYXRhfSBmcm9tIFwiLi4vLi4vc2VydmljZXMvdGltZWxvZ3Muc2VydmljZVwiO1xyXG5pbXBvcnQge1JvdXRlcn0gZnJvbSBcImFuZ3VsYXIyL3JvdXRlclwiO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ3RpbWUtbG9ncycsXHJcbiAgICB0ZW1wbGF0ZTogYFxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJyb3dcIj5cclxuICAgICAgICAgICAgPGgxPlRpbWUgTG9nczwvaDE+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cInJvd1wiPlxyXG4gICAgICAgIDx0YWJsZSBjbGFzcz1cInRhYmxlIHRhYmxlLWJvcmRlcmVkIHRhYmxlLXN0cmlwZWRcIj5cclxuICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgPHRoPiM8L3RoPiBcclxuICAgICAgICAgICAgICAgIDx0aD5EZXNjcmlwdGlvbjwvdGg+IFxyXG4gICAgICAgICAgICAgICAgPHRoPlRpbWUgaW4gbWludXRlczwvdGg+IFxyXG4gICAgICAgICAgICAgICAgPHRoPkFjdGlvbnM8L3RoPlxyXG4gICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICA8dHIgKm5nRm9yPVwiI3RpbWVMb2cgb2YgdGltZUxvZ3MuZGF0YVwiPlxyXG4gICAgICAgICAgICAgICAgPHRoIHNjb3BlPVwicm93XCI+e3t0aW1lTG9nLmlkfX08L3RoPiBcclxuICAgICAgICAgICAgICAgIDx0ZD57e3RpbWVMb2cuZGVzY3JpcHRpb259fTwvdGQ+IFxyXG4gICAgICAgICAgICAgICAgPHRkPnt7Zm9ybWF0VGltZSh0aW1lTG9nLnRpbWVJbk1pbnV0ZXMpfX0gPC90ZD5cclxuICAgICAgICAgICAgICAgIDx0ZD48c3BhbiAoY2xpY2spPVwiZWRpdFRpbWVMb2codGltZUxvZylcIiBjbGFzcz1cImNvbC1zbS0yXCI+RWRpdDwvc3Bhbj48c3BhbiAoY2xpY2spPVwiZGVsZXRlVGltZUxvZyh0aW1lTG9nKVwiIGNsYXNzPVwiY29sLXNtLTJcIj5EZWxldGU8L3NwYW4+PC90ZD5cclxuICAgICAgICAgICAgPC90cj5cclxuICAgICAgICA8L3RhYmxlPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJyb3dcIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJjb2wtc20tMiBjb2wtbWQtb2Zmc2V0LTZcIj5Ub3RhbDo8L3NwYW4+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiY29sLXNtLTJcIj57e3Nob3dUb3RhbFRpbWUoKX19PC9zcGFuPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgYCxcclxuICAgIGRpcmVjdGl2ZXM6IFtOZ0NsYXNzLCBOZ0lmLCBDT1JFX0RJUkVDVElWRVMsIEZPUk1fRElSRUNUSVZFU11cclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBUaW1lTG9nc0NvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcbiAgICB0aW1lTG9nczogVGltZUxvZ3NEYXRhO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgX3JvdXRlcjogUm91dGVyLCBwcml2YXRlIF90aW1lTG9nc1NlcnZpY2U6IFRpbWVMb2dzU2VydmljZSkge1xyXG4gICAgICAgIHRoaXMudGltZUxvZ3MgPSBfdGltZUxvZ3NTZXJ2aWNlLnRpbWVMb2dzO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25Jbml0ICgpIHtcclxuICAgICAgICB0aGlzLmdldFRpbWVMb2dzKCk7XHJcbiAgICB9XHJcblxyXG4gICAgZ2V0VGltZUxvZ3MoKSB7XHJcbiAgICAgICAgdGhpcy5fdGltZUxvZ3NTZXJ2aWNlLmdldFRpbWVMb2dzKCk7XHJcbiAgICAgICAgICAgIC8vIC5zdWJzY3JpYmUoZnVuY3Rpb24oaGVyb2VzKSB7cmV0dXJuIHRoaXMudGltZUxvZ3MgPSBoZXJvZXN9KTtcclxuICAgICAgICAvLyB0aGlzLnRpbWVMb2dzID0gdGhpcy5fdGltZUxvZ3NTZXJ2aWNlLmdldFRpbWVMb2dzKCk7XHJcbiAgICAgICAgLy8gdGhpcy50b3RhbCA9IF8ucmVkdWNlKHRoaXMudGltZUxvZ3MsIGZ1bmN0aW9uKHN1bW0sIHRpbWVMb2cpe1xyXG4gICAgICAgIC8vICAgICAgcmV0dXJuIHN1bW0gKyB0aW1lTG9nLnRpbWVJbk1pbnV0ZXM7XHJcbiAgICAgICAgLy8gfSwgMCk7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2codGhpcy50b3RhbCk7XHJcbiAgICB9XHJcbiAgICBcclxuICAgIHNob3dUb3RhbFRpbWUoKSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuZm9ybWF0VGltZShfLnJlZHVjZSh0aGlzLnRpbWVMb2dzLmRhdGEsIGZ1bmN0aW9uKHN1bW0sIHRpbWVMb2cpe1xyXG4gICAgICAgICAgICAgICAgIHJldHVybiBzdW1tICsgdGltZUxvZy50aW1lSW5NaW51dGVzO1xyXG4gICAgICAgICAgICB9LCAwKSk7XHJcbiAgICB9XHJcblxyXG4gICAgZm9ybWF0VGltZSh0aW1lSW5NaW51dGVzKSB7XHJcbiAgICAgICAgdmFyIHRpbWVTdHJpbmcgPSBcIlwiO1xyXG4gICAgICAgIHZhciBob3VycyA9IE1hdGguZmxvb3IodGltZUluTWludXRlcyAvIDYwKTtcclxuICAgICAgICBpZihob3Vycykge1xyXG4gICAgICAgICAgICB0aW1lU3RyaW5nICs9IGhvdXJzICsgXCIgaG91clwiO1xyXG4gICAgICAgICAgICB0aW1lU3RyaW5nICs9IGhvdXJzID4gMSA/IFwicyBcIiA6IFwiIFwiO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYodGltZUluTWludXRlcyAlIDYwKXtcclxuICAgICAgICAgICAgdGltZVN0cmluZyArPSB0aW1lSW5NaW51dGVzICUgNjAgKyBcIiBtaW51dGVzXCI7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gdGltZVN0cmluZztcclxuICAgIH1cclxuXHJcbiAgICBkZWxldGVUaW1lTG9nKHRpbWVMb2cpIHtcclxuICAgICAgICB0aGlzLl90aW1lTG9nc1NlcnZpY2UuZGVsZXRlVGltZUxvZyh0aW1lTG9nKTtcclxuICAgIH1cclxuXHJcbiAgICBlZGl0VGltZUxvZyh0aW1lTG9nKSB7XHJcbiAgICAgICAgdGhpcy5fcm91dGVyLm5hdmlnYXRlKCBbJ0FkZFRpbWVMb2cnLCB7aWQ6IHRpbWVMb2cuaWR9XSApO1xyXG4gICAgfVxyXG59Il19
