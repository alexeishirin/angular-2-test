System.register(['angular2/core', "../../model/timelog.model", "../../services/timelogs.service", 'angular2/router'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, timelog_model_1, timelogs_service_1, router_1;
    var EditTimeLogComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (timelog_model_1_1) {
                timelog_model_1 = timelog_model_1_1;
            },
            function (timelogs_service_1_1) {
                timelogs_service_1 = timelogs_service_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            }],
        execute: function() {
            EditTimeLogComponent = (function () {
                function EditTimeLogComponent(_routeParams, _router, _timeLogsService) {
                    this._routeParams = _routeParams;
                    this._router = _router;
                    this._timeLogsService = _timeLogsService;
                    this.model = new timelog_model_1.TimeLog();
                    this.submitted = false;
                }
                EditTimeLogComponent.prototype.onSubmit = function () {
                    this.submitted = true;
                    this._timeLogsService.editTimeLog(this.model);
                    this._router.navigate(['TimeLogs']);
                };
                EditTimeLogComponent.prototype.ngOnInit = function () {
                    var id = this._routeParams.get('id');
                    if (id === 'new') {
                        return;
                    }
                    var timeLogById = this._timeLogsService.getTimeLog(+id);
                    if (timeLogById) {
                        this.model = timeLogById;
                    }
                };
                EditTimeLogComponent = __decorate([
                    core_1.Component({
                        selector: 'add-time-log',
                        templateUrl: "app/components/timeLogs/edit-timelog.component.html"
                    }), 
                    __metadata('design:paramtypes', [router_1.RouteParams, router_1.Router, timelogs_service_1.TimeLogsService])
                ], EditTimeLogComponent);
                return EditTimeLogComponent;
            }());
            exports_1("EditTimeLogComponent", EditTimeLogComponent);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC9jb21wb25lbnRzL3RpbWVMb2dzL2VkaXQtdGltZWxvZy5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7WUFVQTtnQkFVSSw4QkFBb0IsWUFBd0IsRUFBVSxPQUFjLEVBQVUsZ0JBQWdDO29CQUExRixpQkFBWSxHQUFaLFlBQVksQ0FBWTtvQkFBVSxZQUFPLEdBQVAsT0FBTyxDQUFPO29CQUFVLHFCQUFnQixHQUFoQixnQkFBZ0IsQ0FBZ0I7b0JBVDlHLFVBQUssR0FBRyxJQUFJLHVCQUFPLEVBQUUsQ0FBQztvQkFDdEIsY0FBUyxHQUFHLEtBQUssQ0FBQztnQkFTbEIsQ0FBQztnQkFQRCx1Q0FBUSxHQUFSO29CQUNJLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDO29CQUN0QixJQUFJLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDOUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDO2dCQUN4QyxDQUFDO2dCQUtELHVDQUFRLEdBQVI7b0JBQ0ksSUFBSSxFQUFFLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQ3JDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsS0FBSyxLQUFLLENBQUMsQ0FBQyxDQUFDO3dCQUNmLE1BQU0sQ0FBQztvQkFDWCxDQUFDO29CQUVELElBQUksV0FBVyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztvQkFDeEQsRUFBRSxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQzt3QkFDZCxJQUFJLENBQUMsS0FBSyxHQUFHLFdBQVcsQ0FBQztvQkFDN0IsQ0FBQztnQkFDTCxDQUFDO2dCQTVCTDtvQkFBQyxnQkFBUyxDQUFDO3dCQUNQLFFBQVEsRUFBRSxjQUFjO3dCQUN4QixXQUFXLEVBQUUscURBQXFEO3FCQUNyRSxDQUFDOzt3Q0FBQTtnQkEwQkYsMkJBQUM7WUFBRCxDQXhCQSxBQXdCQyxJQUFBO1lBeEJELHVEQXdCQyxDQUFBIiwiZmlsZSI6ImFwcC9jb21wb25lbnRzL3RpbWVMb2dzL2VkaXQtdGltZWxvZy5jb21wb25lbnQuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge0NvbXBvbmVudCwgT25Jbml0fSBmcm9tICdhbmd1bGFyMi9jb3JlJztcclxuaW1wb3J0IHtUaW1lTG9nfSBmcm9tIFwiLi4vLi4vbW9kZWwvdGltZWxvZy5tb2RlbFwiO1xyXG5pbXBvcnQge1RpbWVMb2dzU2VydmljZX0gZnJvbSBcIi4uLy4uL3NlcnZpY2VzL3RpbWVsb2dzLnNlcnZpY2VcIjtcclxuaW1wb3J0IHtSb3V0ZXIsIFJvdXRlUGFyYW1zfSBmcm9tICdhbmd1bGFyMi9yb3V0ZXInO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2FkZC10aW1lLWxvZycsXHJcbiAgICB0ZW1wbGF0ZVVybDogXCJhcHAvY29tcG9uZW50cy90aW1lTG9ncy9lZGl0LXRpbWVsb2cuY29tcG9uZW50Lmh0bWxcIlxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEVkaXRUaW1lTG9nQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcclxuICAgIG1vZGVsID0gbmV3IFRpbWVMb2coKTtcclxuICAgIHN1Ym1pdHRlZCA9IGZhbHNlO1xyXG5cclxuICAgIG9uU3VibWl0KCkge1xyXG4gICAgICAgIHRoaXMuc3VibWl0dGVkID0gdHJ1ZTtcclxuICAgICAgICB0aGlzLl90aW1lTG9nc1NlcnZpY2UuZWRpdFRpbWVMb2codGhpcy5tb2RlbCk7XHJcbiAgICAgICAgdGhpcy5fcm91dGVyLm5hdmlnYXRlKFsnVGltZUxvZ3MnXSk7XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBfcm91dGVQYXJhbXM6Um91dGVQYXJhbXMsIHByaXZhdGUgX3JvdXRlcjpSb3V0ZXIsIHByaXZhdGUgX3RpbWVMb2dzU2VydmljZTpUaW1lTG9nc1NlcnZpY2UpIHtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uSW5pdCgpIHtcclxuICAgICAgICBsZXQgaWQgPSB0aGlzLl9yb3V0ZVBhcmFtcy5nZXQoJ2lkJyk7XHJcbiAgICAgICAgaWYgKGlkID09PSAnbmV3Jykge1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gXHJcbiAgICAgICAgdmFyIHRpbWVMb2dCeUlkID0gdGhpcy5fdGltZUxvZ3NTZXJ2aWNlLmdldFRpbWVMb2coK2lkKTtcclxuICAgICAgICBpZiAodGltZUxvZ0J5SWQpIHtcclxuICAgICAgICAgICAgdGhpcy5tb2RlbCA9IHRpbWVMb2dCeUlkO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufSJdfQ==
