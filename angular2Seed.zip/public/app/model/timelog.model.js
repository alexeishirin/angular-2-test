System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var TimeLog;
    return {
        setters:[],
        execute: function() {
            TimeLog = (function () {
                function TimeLog() {
                }
                return TimeLog;
            }());
            exports_1("TimeLog", TimeLog);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC9tb2RlbC90aW1lbG9nLm1vZGVsLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7WUFBQTtnQkFBQTtnQkFJQSxDQUFDO2dCQUFELGNBQUM7WUFBRCxDQUpBLEFBSUMsSUFBQTtZQUpELDZCQUlDLENBQUEiLCJmaWxlIjoiYXBwL21vZGVsL3RpbWVsb2cubW9kZWwuanMiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgY2xhc3MgVGltZUxvZyB7XHJcbiAgICBpZDogbnVtYmVyO1xyXG4gICAgZGVzY3JpcHRpb246IHN0cmluZztcclxuICAgIHRpbWVJbk1pbnV0ZXM6IG51bWJlcjtcclxufSJdfQ==
