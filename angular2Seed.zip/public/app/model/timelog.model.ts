export class TimeLog {
    id: number;
    description: string;
    timeInMinutes: number;
}