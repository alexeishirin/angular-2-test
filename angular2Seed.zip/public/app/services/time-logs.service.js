System.register(['angular2/core', 'angular2/http', 'rxjs/Rx', "lodash"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, http_1, _;
    var TimeLogsService;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (http_1_1) {
                http_1 = http_1_1;
            },
            function (_1) {},
            function (_2) {
                _ = _2;
            }],
        execute: function() {
            TimeLogsService = (function () {
                function TimeLogsService(http) {
                    this.http = http;
                    this._timelogsAPIUrl = 'api/timelogs';
                    this.timeLogs = { data: [] };
                }
                ;
                TimeLogsService.prototype.getTimeLogs = function () {
                    if (_.isEmpty(this.timeLogs.data)) {
                        this._getTimeLogs();
                    }
                };
                TimeLogsService.prototype._getTimeLogs = function () {
                    var _this = this;
                    // this.timeLogs.timeLogs = [{"id": 1, "description": "Installing Node JS", "timeInMinutes": 5}];
                    this.http.get(this._timelogsAPIUrl)
                        .map(this.extractData)
                        .subscribe(function (timeLogs) {
                        _this.timeLogs.data = timeLogs;
                        console.log(_this.timeLogs);
                    });
                };
                TimeLogsService.prototype.getTimeLog = function (id) {
                    return _.find(this.timeLogs.data, { id: id });
                };
                TimeLogsService.prototype.editTimeLog = function (timeLog) {
                    if (timeLog.id) {
                        var timeLogToEdit = _.find(this.timeLogs.data, { id: timeLog.id });
                        _.assign(timeLogToEdit, timeLog);
                    }
                    else {
                        var newId = _.maxBy(this.timeLogs.data, 'id').id + 1;
                        _.assign(timeLog, { id: newId });
                        this.timeLogs.data.push(timeLog);
                    }
                };
                TimeLogsService.prototype.deleteTimeLog = function (timeLog) {
                    _.remove(this.timeLogs.data, timeLog);
                };
                TimeLogsService.prototype.extractData = function (res) {
                    var body = res.json();
                    return body.data || [];
                };
                TimeLogsService = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [(typeof (_a = typeof http_1.Http !== 'undefined' && http_1.Http) === 'function' && _a) || Object])
                ], TimeLogsService);
                return TimeLogsService;
                var _a;
            }());
            exports_1("TimeLogsService", TimeLogsService);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC9zZXJ2aWNlcy90aW1lLWxvZ3Muc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7WUFZQTtnQkFDSSx5QkFBcUIsSUFBVTtvQkFBVixTQUFJLEdBQUosSUFBSSxDQUFNO29CQUV2QixvQkFBZSxHQUFHLGNBQWMsQ0FBQztvQkFDekMsYUFBUSxHQUFrQixFQUFDLElBQUksRUFBRyxFQUFFLEVBQUMsQ0FBQztnQkFISixDQUFDOztnQkFLbkMscUNBQVcsR0FBWDtvQkFDSSxFQUFFLENBQUEsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUMvQixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7b0JBQ3hCLENBQUM7Z0JBQ0wsQ0FBQztnQkFFRCxzQ0FBWSxHQUFaO29CQUFBLGlCQVFDO29CQVBHLGlHQUFpRztvQkFDakcsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQzt5QkFDOUIsR0FBRyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUM7eUJBQ3JCLFNBQVMsQ0FBQyxVQUFDLFFBQVE7d0JBQ2hCLEtBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxHQUFHLFFBQVEsQ0FBQzt3QkFDOUIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7b0JBQy9CLENBQUMsQ0FBQyxDQUFDO2dCQUNYLENBQUM7Z0JBRUQsb0NBQVUsR0FBVixVQUFXLEVBQVc7b0JBQ2xCLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLEVBQUMsRUFBRSxFQUFFLEVBQUUsRUFBQyxDQUFDLENBQUM7Z0JBQ2hELENBQUM7Z0JBRUQscUNBQVcsR0FBWCxVQUFZLE9BQWlCO29CQUN6QixFQUFFLENBQUEsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQzt3QkFDWixJQUFJLGFBQWEsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLEVBQUMsRUFBRSxFQUFFLE9BQU8sQ0FBQyxFQUFFLEVBQUMsQ0FBQyxDQUFDO3dCQUNqRSxDQUFDLENBQUMsTUFBTSxDQUFDLGFBQWEsRUFBRSxPQUFPLENBQUMsQ0FBQztvQkFDckMsQ0FBQztvQkFBQyxJQUFJLENBQUMsQ0FBQzt3QkFDSixJQUFJLEtBQUssR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7d0JBQ3JELENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFLEVBQUMsRUFBRSxFQUFFLEtBQUssRUFBQyxDQUFDLENBQUM7d0JBQy9CLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztvQkFDckMsQ0FBQztnQkFDTCxDQUFDO2dCQUVELHVDQUFhLEdBQWIsVUFBYyxPQUFpQjtvQkFDM0IsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsQ0FBQztnQkFDMUMsQ0FBQztnQkFFTyxxQ0FBVyxHQUFuQixVQUFvQixHQUFhO29CQUM3QixJQUFJLElBQUksR0FBRyxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ3RCLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLEVBQUUsQ0FBQztnQkFDM0IsQ0FBQztnQkE3Q0w7b0JBQUMsaUJBQVUsRUFBRTs7bUNBQUE7Z0JBOENiLHNCQUFDOztZQUFELENBN0NBLEFBNkNDLElBQUE7WUE3Q0QsNkNBNkNDLENBQUEiLCJmaWxlIjoiYXBwL3NlcnZpY2VzL3RpbWUtbG9ncy5zZXJ2aWNlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtJbmplY3RhYmxlfSBmcm9tICdhbmd1bGFyMi9jb3JlJztcclxuaW1wb3J0IHtIdHRwLCBSZXNwb25zZX0gZnJvbSAnYW5ndWxhcjIvaHR0cCc7XHJcbmltcG9ydCB7VGltZUxvZ30gZnJvbSBcIi4uL21vZGVsL1RpbWVMb2dcIjtcclxuaW1wb3J0IHtPYnNlcnZhYmxlfSBmcm9tIFwicnhqcy9PYnNlcnZhYmxlXCI7XHJcbmltcG9ydCAncnhqcy9SeCc7XHJcbmltcG9ydCAqIGFzIF8gZnJvbSBcImxvZGFzaFwiO1xyXG5cclxuZXhwb3J0IGludGVyZmFjZSBUaW1lTG9nc0RhdGEge1xyXG4gICAgZGF0YTogVGltZUxvZ1tdO1xyXG59XHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBUaW1lTG9nc1NlcnZpY2Uge1xyXG4gICAgY29uc3RydWN0b3IgKHByaXZhdGUgaHR0cDogSHR0cCkge307XHJcblxyXG4gICAgcHJpdmF0ZSBfdGltZWxvZ3NBUElVcmwgPSAnYXBpL3RpbWVsb2dzJztcclxuICAgIHRpbWVMb2dzIDogVGltZUxvZ3NEYXRhID0ge2RhdGEgOiBbXX07XHJcblxyXG4gICAgZ2V0VGltZUxvZ3MoKSB7XHJcbiAgICAgICAgaWYoXy5pc0VtcHR5KHRoaXMudGltZUxvZ3MuZGF0YSkpIHtcclxuICAgICAgICAgICAgdGhpcy5fZ2V0VGltZUxvZ3MoKTtcclxuICAgICAgICB9ICAgICAgICBcclxuICAgIH1cclxuXHJcbiAgICBfZ2V0VGltZUxvZ3MoKSB7XHJcbiAgICAgICAgLy8gdGhpcy50aW1lTG9ncy50aW1lTG9ncyA9IFt7XCJpZFwiOiAxLCBcImRlc2NyaXB0aW9uXCI6IFwiSW5zdGFsbGluZyBOb2RlIEpTXCIsIFwidGltZUluTWludXRlc1wiOiA1fV07XHJcbiAgICAgICAgdGhpcy5odHRwLmdldCh0aGlzLl90aW1lbG9nc0FQSVVybClcclxuICAgICAgICAgICAgLm1hcCh0aGlzLmV4dHJhY3REYXRhKVxyXG4gICAgICAgICAgICAuc3Vic2NyaWJlKCh0aW1lTG9ncykgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy50aW1lTG9ncy5kYXRhID0gdGltZUxvZ3M7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyh0aGlzLnRpbWVMb2dzKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICB9XHJcbiAgICBcclxuICAgIGdldFRpbWVMb2coaWQgOiBudW1iZXIpIHtcclxuICAgICAgICByZXR1cm4gXy5maW5kKHRoaXMudGltZUxvZ3MuZGF0YSwge2lkOiBpZH0pO1xyXG4gICAgfVxyXG4gICAgXHJcbiAgICBlZGl0VGltZUxvZyh0aW1lTG9nIDogVGltZUxvZykge1xyXG4gICAgICAgIGlmKHRpbWVMb2cuaWQpIHtcclxuICAgICAgICAgICAgdmFyIHRpbWVMb2dUb0VkaXQgPSBfLmZpbmQodGhpcy50aW1lTG9ncy5kYXRhLCB7aWQ6IHRpbWVMb2cuaWR9KTtcclxuICAgICAgICAgICAgXy5hc3NpZ24odGltZUxvZ1RvRWRpdCwgdGltZUxvZyk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdmFyIG5ld0lkID0gXy5tYXhCeSh0aGlzLnRpbWVMb2dzLmRhdGEsICdpZCcpLmlkICsgMTtcclxuICAgICAgICAgICAgXy5hc3NpZ24odGltZUxvZywge2lkOiBuZXdJZH0pO1xyXG4gICAgICAgICAgICB0aGlzLnRpbWVMb2dzLmRhdGEucHVzaCh0aW1lTG9nKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBcclxuICAgIGRlbGV0ZVRpbWVMb2codGltZUxvZyA6IFRpbWVMb2cpIHtcclxuICAgICAgICBfLnJlbW92ZSh0aGlzLnRpbWVMb2dzLmRhdGEsIHRpbWVMb2cpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgZXh0cmFjdERhdGEocmVzOiBSZXNwb25zZSkge1xyXG4gICAgICAgIGxldCBib2R5ID0gcmVzLmpzb24oKTtcclxuICAgICAgICByZXR1cm4gYm9keS5kYXRhIHx8IFtdO1xyXG4gICAgfVxyXG59Il19
