System.register(['angular2/core', 'angular2/http', 'rxjs/Rx', "lodash"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, http_1, _;
    var TimeLogsService;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (http_1_1) {
                http_1 = http_1_1;
            },
            function (_1) {},
            function (_2) {
                _ = _2;
            }],
        execute: function() {
            TimeLogsService = (function () {
                function TimeLogsService(http) {
                    this.http = http;
                    this._timelogsAPIUrl = 'api/timelogs';
                    this.timeLogs = { data: [] };
                }
                ;
                TimeLogsService.prototype.getTimeLogs = function () {
                    if (_.isEmpty(this.timeLogs.data)) {
                        this._getTimeLogs();
                    }
                };
                TimeLogsService.prototype._getTimeLogs = function () {
                    var _this = this;
                    // this.timeLogs.timeLogs = [{"id": 1, "description": "Installing Node JS", "timeInMinutes": 5}];
                    this.http.get(this._timelogsAPIUrl)
                        .map(this.extractData)
                        .subscribe(function (timeLogs) {
                        _this.timeLogs.data = timeLogs;
                        console.log(_this.timeLogs);
                    });
                };
                TimeLogsService.prototype.getTimeLog = function (id) {
                    return _.find(this.timeLogs.data, { id: id });
                };
                TimeLogsService.prototype.editTimeLog = function (timeLog) {
                    timeLog.timeInMinutes = +timeLog.timeInMinutes;
                    if (timeLog.id) {
                        var timeLogToEdit = _.find(this.timeLogs.data, { id: timeLog.id });
                        _.assign(timeLogToEdit, timeLog);
                    }
                    else {
                        var newId = _.maxBy(this.timeLogs.data, 'id').id + 1;
                        _.assign(timeLog, { id: newId });
                        this.timeLogs.data.push(timeLog);
                    }
                };
                TimeLogsService.prototype.deleteTimeLog = function (timeLog) {
                    _.remove(this.timeLogs.data, timeLog);
                };
                TimeLogsService.prototype.extractData = function (res) {
                    var body = res.json();
                    return body.data || [];
                };
                TimeLogsService = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [http_1.Http])
                ], TimeLogsService);
                return TimeLogsService;
            }());
            exports_1("TimeLogsService", TimeLogsService);
        }
    }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC9zZXJ2aWNlcy90aW1lbG9ncy5zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztZQVlBO2dCQUNJLHlCQUFxQixJQUFVO29CQUFWLFNBQUksR0FBSixJQUFJLENBQU07b0JBRXZCLG9CQUFlLEdBQUcsY0FBYyxDQUFDO29CQUN6QyxhQUFRLEdBQWtCLEVBQUMsSUFBSSxFQUFHLEVBQUUsRUFBQyxDQUFDO2dCQUhKLENBQUM7O2dCQUtuQyxxQ0FBVyxHQUFYO29CQUNJLEVBQUUsQ0FBQSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQy9CLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztvQkFDeEIsQ0FBQztnQkFDTCxDQUFDO2dCQUVELHNDQUFZLEdBQVo7b0JBQUEsaUJBUUM7b0JBUEcsaUdBQWlHO29CQUNqRyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDO3lCQUM5QixHQUFHLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQzt5QkFDckIsU0FBUyxDQUFDLFVBQUMsUUFBUTt3QkFDaEIsS0FBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEdBQUcsUUFBUSxDQUFDO3dCQUM5QixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFDL0IsQ0FBQyxDQUFDLENBQUM7Z0JBQ1gsQ0FBQztnQkFFRCxvQ0FBVSxHQUFWLFVBQVcsRUFBVztvQkFDbEIsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsRUFBQyxFQUFFLEVBQUUsRUFBRSxFQUFDLENBQUMsQ0FBQztnQkFDaEQsQ0FBQztnQkFFRCxxQ0FBVyxHQUFYLFVBQVksT0FBaUI7b0JBQ3pCLE9BQU8sQ0FBQyxhQUFhLEdBQUcsQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDO29CQUMvQyxFQUFFLENBQUEsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQzt3QkFDWixJQUFJLGFBQWEsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLEVBQUMsRUFBRSxFQUFFLE9BQU8sQ0FBQyxFQUFFLEVBQUMsQ0FBQyxDQUFDO3dCQUNqRSxDQUFDLENBQUMsTUFBTSxDQUFDLGFBQWEsRUFBRSxPQUFPLENBQUMsQ0FBQztvQkFDckMsQ0FBQztvQkFBQyxJQUFJLENBQUMsQ0FBQzt3QkFDSixJQUFJLEtBQUssR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7d0JBQ3JELENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFLEVBQUMsRUFBRSxFQUFFLEtBQUssRUFBQyxDQUFDLENBQUM7d0JBQy9CLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztvQkFDckMsQ0FBQztnQkFDTCxDQUFDO2dCQUVELHVDQUFhLEdBQWIsVUFBYyxPQUFpQjtvQkFDM0IsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsQ0FBQztnQkFDMUMsQ0FBQztnQkFFTyxxQ0FBVyxHQUFuQixVQUFvQixHQUFhO29CQUM3QixJQUFJLElBQUksR0FBRyxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ3RCLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLEVBQUUsQ0FBQztnQkFDM0IsQ0FBQztnQkE5Q0w7b0JBQUMsaUJBQVUsRUFBRTs7bUNBQUE7Z0JBK0NiLHNCQUFDO1lBQUQsQ0E5Q0EsQUE4Q0MsSUFBQTtZQTlDRCw2Q0E4Q0MsQ0FBQSIsImZpbGUiOiJhcHAvc2VydmljZXMvdGltZWxvZ3Muc2VydmljZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7SW5qZWN0YWJsZX0gZnJvbSAnYW5ndWxhcjIvY29yZSc7XHJcbmltcG9ydCB7SHR0cCwgUmVzcG9uc2V9IGZyb20gJ2FuZ3VsYXIyL2h0dHAnO1xyXG5pbXBvcnQge1RpbWVMb2d9IGZyb20gXCIuLi9tb2RlbC90aW1lbG9nLm1vZGVsXCI7XHJcbmltcG9ydCB7T2JzZXJ2YWJsZX0gZnJvbSBcInJ4anMvT2JzZXJ2YWJsZVwiO1xyXG5pbXBvcnQgJ3J4anMvUngnO1xyXG5pbXBvcnQgKiBhcyBfIGZyb20gXCJsb2Rhc2hcIjtcclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgVGltZUxvZ3NEYXRhIHtcclxuICAgIGRhdGE6IFRpbWVMb2dbXTtcclxufVxyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgVGltZUxvZ3NTZXJ2aWNlIHtcclxuICAgIGNvbnN0cnVjdG9yIChwcml2YXRlIGh0dHA6IEh0dHApIHt9O1xyXG5cclxuICAgIHByaXZhdGUgX3RpbWVsb2dzQVBJVXJsID0gJ2FwaS90aW1lbG9ncyc7XHJcbiAgICB0aW1lTG9ncyA6IFRpbWVMb2dzRGF0YSA9IHtkYXRhIDogW119O1xyXG5cclxuICAgIGdldFRpbWVMb2dzKCkge1xyXG4gICAgICAgIGlmKF8uaXNFbXB0eSh0aGlzLnRpbWVMb2dzLmRhdGEpKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2dldFRpbWVMb2dzKCk7XHJcbiAgICAgICAgfSAgICAgICAgXHJcbiAgICB9XHJcblxyXG4gICAgX2dldFRpbWVMb2dzKCkge1xyXG4gICAgICAgIC8vIHRoaXMudGltZUxvZ3MudGltZUxvZ3MgPSBbe1wiaWRcIjogMSwgXCJkZXNjcmlwdGlvblwiOiBcIkluc3RhbGxpbmcgTm9kZSBKU1wiLCBcInRpbWVJbk1pbnV0ZXNcIjogNX1dO1xyXG4gICAgICAgIHRoaXMuaHR0cC5nZXQodGhpcy5fdGltZWxvZ3NBUElVcmwpXHJcbiAgICAgICAgICAgIC5tYXAodGhpcy5leHRyYWN0RGF0YSlcclxuICAgICAgICAgICAgLnN1YnNjcmliZSgodGltZUxvZ3MpID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMudGltZUxvZ3MuZGF0YSA9IHRpbWVMb2dzO1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2codGhpcy50aW1lTG9ncyk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgfVxyXG4gICAgXHJcbiAgICBnZXRUaW1lTG9nKGlkIDogbnVtYmVyKSB7XHJcbiAgICAgICAgcmV0dXJuIF8uZmluZCh0aGlzLnRpbWVMb2dzLmRhdGEsIHtpZDogaWR9KTtcclxuICAgIH1cclxuICAgIFxyXG4gICAgZWRpdFRpbWVMb2codGltZUxvZyA6IFRpbWVMb2cpIHtcclxuICAgICAgICB0aW1lTG9nLnRpbWVJbk1pbnV0ZXMgPSArdGltZUxvZy50aW1lSW5NaW51dGVzO1xyXG4gICAgICAgIGlmKHRpbWVMb2cuaWQpIHtcclxuICAgICAgICAgICAgdmFyIHRpbWVMb2dUb0VkaXQgPSBfLmZpbmQodGhpcy50aW1lTG9ncy5kYXRhLCB7aWQ6IHRpbWVMb2cuaWR9KTtcclxuICAgICAgICAgICAgXy5hc3NpZ24odGltZUxvZ1RvRWRpdCwgdGltZUxvZyk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdmFyIG5ld0lkID0gXy5tYXhCeSh0aGlzLnRpbWVMb2dzLmRhdGEsICdpZCcpLmlkICsgMTtcclxuICAgICAgICAgICAgXy5hc3NpZ24odGltZUxvZywge2lkOiBuZXdJZH0pO1xyXG4gICAgICAgICAgICB0aGlzLnRpbWVMb2dzLmRhdGEucHVzaCh0aW1lTG9nKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBcclxuICAgIGRlbGV0ZVRpbWVMb2codGltZUxvZyA6IFRpbWVMb2cpIHtcclxuICAgICAgICBfLnJlbW92ZSh0aGlzLnRpbWVMb2dzLmRhdGEsIHRpbWVMb2cpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgZXh0cmFjdERhdGEocmVzOiBSZXNwb25zZSkge1xyXG4gICAgICAgIGxldCBib2R5ID0gcmVzLmpzb24oKTtcclxuICAgICAgICByZXR1cm4gYm9keS5kYXRhIHx8IFtdO1xyXG4gICAgfVxyXG59Il19
